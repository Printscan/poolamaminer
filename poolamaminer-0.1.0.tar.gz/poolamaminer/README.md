# Custom Miner Packages

## AMA Miner (`amaminer`)
Custom wrapper for launching `ama-miner` inside Hive OS. Includes scripts to generate config, run the miner, collect stats, and optional `nvtool` tuning from flight sheet user config.

### Installation
1. Copy `amaminer-0.1.1.tar.gz` to `/hive/miners/custom/` on the rig.
2. Install via Hive Shell: `tar -zxf amaminer-0.1.1.tar.gz`.
3. In your flight sheet set `CUSTOM_MINER=amaminer` and leave install URL empty (local install).

### Flight Sheet Variables
- **Wallet (CUSTOM_TEMPLATE):** address or pool login.
- **Pool URL (CUSTOM_URL):** e.g. `host:port`. Multiple entries separated by commas.
- **Password (CUSTOM_PASS):** optional; defaults to `%WORKER_NAME%`.
- **User Config (CUSTOM_USER_CONFIG):** extra miner flags and optional `nvtool` commands. Example: `nvtool --setcoreoffset 150 --setclocks 2400 --setmem 7001 --setmemoffset 2000 --setpl 280 --algo custom`.

### Included Scripts
- `h-config.sh` – generates `/hive/miners/custom/amaminer/config.env`.
- `h-run.sh` – applies `nvtool` settings then starts `ama-miner`.
- `h-stats.sh` – reads `/run/hive/` GPU telemetry and miner logs to report stats.
- `h-manifest.conf` – basic Hive manifest.

### Packaging
Rebuild the archive after changes:
```bash
tar -zcvf amaminer-<version>.tar.gz amaminer
```

## Pool AMA Miner (`poolamaminer`)
Wrapper around the `gpu` binary that expects `RIG`, `SECRET`, and `WALLET` environment variables.

### Installation
1. Copy the `poolamaminer` directory to `/hive/miners/custom/` (or package it similarly with `tar -zcvf poolamaminer-<version>.tar.gz poolamaminer`).
2. Set `CUSTOM_MINER=poolamaminer` in your flight sheet when using this version.

### Flight Sheet Variables
- **Wallet (CUSTOM_TEMPLATE):** populates `WALLET` env variable.
- **Password (CUSTOM_PASS):** used as `SECRET` (defaults to `%WORKER_NAME%`).
- **User Config (CUSTOM_USER_CONFIG):**
  - Override env vars: `RIG=RigName`, `SECRET=secret123`, `POOL=stratum+tcp://...`.
  - CLI flags passed to the miner.
  - Optional `nvtool` commands (same syntax as above): e.g. `nvtool --setclocks 2400 --setmem 7001`.

### Scripts
- `h-config.sh` – builds `config.env` with `RIG`, `SECRET`, `WALLET`, optional `POOL`, and remaining extra args.
- `h-run.sh` – applies `nvtool` settings, exports env vars, and runs `gpu` with remaining args.
- `h-stats.sh` – parses `gpu` log lines (`GPU[x] value shares`) and `/run/hive/gpu-stats.json` to provide Hive stats.
- `h-manifest.conf` – manifest for Hive OS.

### Packaging
```bash
tar -zcvf poolamaminer-<version>.tar.gz poolamaminer
```
